(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const navigation = document.getElementById('navigation');
  const packs = document.querySelector('.nav-packs');
  const packsButton = document.querySelector('.nav-packs-trigger');
  if (menuButton && navigation) {
    menuButton.addEventListener('click', () => {
      const open = navigation.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(open));
      if (!open && packs && packsButton) {
        packs.classList.remove('open');
        packsButton.setAttribute('aria-expanded', 'false');
      }
    });
    navigation.addEventListener('click', event => {
      if (event.target.closest('a')) {
        navigation.classList.remove('open');
        menuButton.setAttribute('aria-expanded', 'false');
        if (packs && packsButton) {
          packs.classList.remove('open');
          packsButton.setAttribute('aria-expanded', 'false');
        }
      }
    });
  }
  if (packs && packsButton) {
    const touchOrMobile = window.matchMedia('(max-width: 767px), (hover: none)');
    packs.addEventListener('mouseenter', () => {
      if (!touchOrMobile.matches) packsButton.setAttribute('aria-expanded', 'true');
    });
    packs.addEventListener('mouseleave', () => {
      if (!touchOrMobile.matches && !packs.contains(document.activeElement)) packsButton.setAttribute('aria-expanded', 'false');
    });
    packs.addEventListener('focusin', () => packsButton.setAttribute('aria-expanded', 'true'));
    packs.addEventListener('focusout', event => {
      if (!packs.contains(event.relatedTarget) && !packs.classList.contains('open')) packsButton.setAttribute('aria-expanded', 'false');
    });
    packsButton.addEventListener('click', () => {
      if (touchOrMobile.matches) {
        const open = packs.classList.toggle('open');
        packsButton.setAttribute('aria-expanded', String(open));
      }
    });
    document.addEventListener('click', event => {
      if (!packs.contains(event.target)) {
        packs.classList.remove('open');
        packsButton.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        packs.classList.remove('open');
        packsButton.setAttribute('aria-expanded', 'false');
      }
    });
  }
  const productQuantity = document.getElementById('product-quantity');
  const secondaryQuantities = document.querySelectorAll('[data-cart-quantity], [data-express-quantity], [data-buy-quantity], [data-product-buy-quantity]');
  const orderStart = document.querySelector('[data-order-start]');
  const customerSubmit = document.querySelector('.customer-submit');
  const mobileBuyButton = document.querySelector('.mobile-buy-bar .button');
  const productBuyButton = document.querySelector('[data-product-buy-button]');
  let selectedVariantAvailable = true;
  let selectedVariantId = '';
  const productAvailable = productBuyButton ? productBuyButton.dataset.productAvailable !== 'false' : true;
  const updateQuantityState = () => {
    const quantity = parseInt(productQuantity?.value, 10) || 0;
    const valid = quantity > 0 && productAvailable && selectedVariantAvailable;
    [orderStart, customerSubmit, mobileBuyButton, productBuyButton].forEach(button => {
      if (button) button.disabled = !valid;
    });
  };
  if (productQuantity && secondaryQuantities.length) {
    const syncQuantity = () => secondaryQuantities.forEach(input => { input.value = productQuantity.value || '1'; });
    syncQuantity();
    productQuantity.addEventListener('input', syncQuantity);
    productQuantity.addEventListener('change', syncQuantity);
    productQuantity.addEventListener('input', updateQuantityState);
    productQuantity.addEventListener('change', updateQuantityState);
  }
  if (productQuantity) updateQuantityState();
  document.querySelectorAll('[data-quantity-increment], [data-quantity-decrement]').forEach(button => {
    button.addEventListener('click', () => {
      if (!productQuantity || productQuantity.disabled) return;
      const current = Math.max(0, parseInt(productQuantity.value, 10) || 0);
      productQuantity.value = button.hasAttribute('data-quantity-increment') ? current + 1 : Math.max(0, current - 1);
      productQuantity.dispatchEvent(new Event('change', {bubbles: true}));
      updateQuantityState();
    });
  });
  const variantPicker = document.querySelector('[data-variant-picker]');
  if (variantPicker) {
    const variantButtons = Array.from(variantPicker.querySelectorAll('[data-variant-id]'));
    const variantSelects = Array.from(document.querySelectorAll('[data-variant-select]'));
    const variantForms = Array.from(document.querySelectorAll('form')).filter(form => form.querySelector('[data-variant-select]'));
    const priceTargets = Array.from(document.querySelectorAll('[data-product-price]'));
    const removeDuplicateVariantInputs = () => {
      variantForms.forEach(form => form.querySelectorAll('input[type="hidden"][name="id"]').forEach(input => input.remove()));
    };
    const syncVariantForms = variantId => {
      if (!variantId) return;
      selectedVariantId = String(variantId);
      removeDuplicateVariantInputs();
      variantForms.forEach(form => {
        form.querySelectorAll('select[name="id"]').forEach(select => { select.value = selectedVariantId; });
      });
    };
    const applyVariant = (variantId, activeButton) => {
      if (!variantId) return;
      syncVariantForms(variantId);
      variantSelects.forEach(select => { select.value = variantId; });
      variantButtons.forEach(button => button.setAttribute('aria-pressed', String(button === activeButton)));
      selectedVariantAvailable = activeButton?.dataset.variantAvailable !== 'false';
      if (activeButton?.dataset.formattedPrice) priceTargets.forEach(target => { target.textContent = activeButton.dataset.formattedPrice; });
      updateQuantityState();
    };
    variantButtons.forEach(button => button.addEventListener('click', () => applyVariant(button.dataset.variantId, button)));
    variantSelects.forEach(select => select.addEventListener('change', () => {
      const activeButton = variantButtons.find(button => button.dataset.variantId === select.value);
      applyVariant(select.value, activeButton);
    }));
    removeDuplicateVariantInputs();
    const initialId = variantSelects[0]?.value || variantButtons.find(button => button.getAttribute('aria-pressed') === 'true')?.dataset.variantId || variantButtons[0]?.dataset.variantId;
    const initialButton = variantButtons.find(button => button.dataset.variantId === initialId);
    applyVariant(initialId, initialButton);
    variantForms.forEach(form => form.addEventListener('submit', () => syncVariantForms(selectedVariantId), true));
  }
  const customerInfo = document.getElementById('customer-info');
  if (orderStart && customerInfo) {
    if (customerInfo.querySelector('.errors')) {
      customerInfo.hidden = false;
      orderStart.setAttribute('aria-expanded', 'true');
    }
    orderStart.addEventListener('click', event => {
      event.preventDefault();
      customerInfo.hidden = false;
      orderStart.setAttribute('aria-expanded', 'true');
      customerInfo.scrollIntoView({behavior: 'smooth', block: 'center'});
      const firstField = customerInfo.querySelector('input:not([type="hidden"]), select, textarea');
      if (firstField) window.setTimeout(() => firstField.focus({preventScroll: true}), 250);
    });
  }
  const syncCardDefaultVariants = () => {
    document.querySelectorAll('[data-default-variant-id] form').forEach(form => {
      const defaultVariantId = form.closest('[data-default-variant-id]')?.dataset.defaultVariantId;
      if (!defaultVariantId) return;
      form.querySelectorAll('input[type="hidden"][name="id"]').forEach(input => input.remove());
      const select = form.querySelector('select[name="id"]');
      if (select) select.value = defaultVariantId;
    });
  };
  syncCardDefaultVariants();
  window.addEventListener('load', syncCardDefaultVariants, {once: true});
  window.setTimeout(syncCardDefaultVariants, 0);
  window.setTimeout(syncCardDefaultVariants, 300);
  document.addEventListener('submit', event => {
    const form = event.target?.closest?.('[data-default-variant-id] form');
    if (!form) return;
    const defaultVariantId = form.closest('[data-default-variant-id]')?.dataset.defaultVariantId;
    if (!defaultVariantId) return;
    form.querySelectorAll('input[type="hidden"][name="id"]').forEach(input => input.remove());
    const select = form.querySelector('select[name="id"]');
    if (select) select.value = defaultVariantId;
  }, true);
  const serializeFormFallback = form => {
    const parts = [];
    form.querySelectorAll('input, select, textarea').forEach(field => {
      if (!field.name || field.disabled) return;
      if ((field.type === 'checkbox' || field.type === 'radio') && !field.checked) return;
      if (field.tagName === 'SELECT' && field.multiple) {
        Array.from(field.selectedOptions).forEach(option => parts.push(`${encodeURIComponent(field.name)}=${encodeURIComponent(option.value)}`));
        return;
      }
      parts.push(`${encodeURIComponent(field.name)}=${encodeURIComponent(field.value)}`);
    });
    return parts.join('&');
  };
  const getFormPayload = form => {
    try {
      if (typeof window.FormData === 'function') return {body: new window.FormData(form), headers: {}};
    } catch (error) {}
    return {body: serializeFormFallback(form), headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}};
  };
  const ensureProductQuantity = form => {
    form.querySelectorAll('input[name="quantity"]').forEach(input => {
      const quantity = Number.parseInt(input.value, 10);
      input.value = Number.isFinite(quantity) && quantity > 0 ? String(quantity) : '1';
      input.setAttribute('value', input.value);
    });
  };
  const getProductVariantId = form => {
    const control = form.querySelector('select[name="id"], input[name="id"]');
    return String(control?.value || '').trim();
  };
  const getYouCanCartApi = () => {
    const sdk = window.youcanjs;
    if (sdk?.cart && typeof sdk.cart.addItem === 'function') return sdk.cart;
    if (sdk && typeof sdk.init === 'function') {
      try {
        const instance = sdk.init();
        if (instance?.cart && typeof instance.cart.addItem === 'function') return instance.cart;
      } catch (error) {}
    }
    return null;
  };
  let cartAddQueue = Promise.resolve();
  let cartAddPending = 0;
  let cartAddSucceeded = false;
  const addCardToCart = button => {
    if (!button || button.disabled || button.dataset.cartAdding === '1') return;
    const form = button.closest('form');
    if (!form) return;
    button.dataset.cartAdding = '1';
    button.disabled = true;
    cartAddPending += 1;
    const task = cartAddQueue.then(async () => {
      ensureProductQuantity(form);
      const productVariantId = getProductVariantId(form);
      const quantity = Math.max(1, Number.parseInt(form.querySelector('input[name="quantity"]')?.value, 10) || 1);
      if (!productVariantId) throw new Error('product variant is missing');
      const cartApi = getYouCanCartApi();
      if (cartApi) {
        await cartApi.addItem({productVariantId, quantity});
      } else {
        HTMLFormElement.prototype.submit.call(form);
        return;
      }
      cartAddSucceeded = true;
    }).catch(() => {
      button.dataset.cartAdding = '0';
      button.disabled = false;
    }).finally(() => {
      cartAddPending -= 1;
      if (!cartAddPending) {
        if (cartAddSucceeded) {
          try { window.sessionStorage.setItem('muskane-cart-open', '1'); } catch (error) {}
          window.location.reload();
        }
        cartAddSucceeded = false;
      }
    });
    cartAddQueue = task.catch(() => {});
  };
  document.querySelectorAll('[data-cart-add]').forEach(button => {
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      addCardToCart(button);
    }, true);
  });
  const cartOpenButton = document.querySelector('[data-cart-open]');
  const cartDrawer = document.getElementById('cart-drawer');
  const cartBackdrop = document.querySelector('[data-cart-backdrop]');
  const cartDrawerForm = document.getElementById('cart-drawer-form');
  let cartPreviousFocus = null;
  const getCartFocusable = () => {
    if (!cartDrawer) return [];
    return Array.from(cartDrawer.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
      .filter(element => !element.hidden && element.getClientRects().length);
  };
  const syncCartQuantityValue = input => {
    const value = input.value || '1';
    const display = input.closest('[data-cart-item]')?.querySelector('[data-cart-quantity-value]');
    if (display) display.textContent = value;
  };
  const normalizeCartQuantities = () => {
    document.querySelectorAll('[data-cart-quantity], .cart-row input[name^="updates["]').forEach(input => {
      const parsed = Number.parseInt(input.value, 10);
      if (!Number.isFinite(parsed) || parsed < 0) input.value = '1';
      input.setAttribute('value', input.value || '1');
      syncCartQuantityValue(input);
    });
  };
  normalizeCartQuantities();
  window.addEventListener('load', normalizeCartQuantities, {once: true});
  window.setTimeout(normalizeCartQuantities, 0);
  window.setTimeout(normalizeCartQuantities, 300);
  let cartUpdating = false;
  const openCartDrawer = () => {
    if (!cartDrawer) return;
    if (!cartPreviousFocus) cartPreviousFocus = document.activeElement;
    cartDrawer.hidden = false;
    cartDrawer.setAttribute('aria-hidden', 'false');
    if (cartBackdrop) cartBackdrop.hidden = false;
    document.body.classList.add('cart-drawer-open');
    window.requestAnimationFrame(() => {
      cartDrawer.classList.add('is-open');
      if (cartOpenButton) cartOpenButton.setAttribute('aria-expanded', 'true');
    });
    cartDrawer.querySelector('[data-cart-close]')?.focus({preventScroll: true});
  };
  const closeCartDrawer = () => {
    if (!cartDrawer) return;
    cartDrawer.classList.remove('is-open');
    document.body.classList.remove('cart-drawer-open');
    if (cartOpenButton) cartOpenButton.setAttribute('aria-expanded', 'false');
    cartDrawer.setAttribute('aria-hidden', 'true');
    const focusTarget = cartPreviousFocus;
    cartPreviousFocus = null;
    window.setTimeout(() => {
      if (!cartDrawer.classList.contains('is-open')) {
        cartDrawer.hidden = true;
        if (cartBackdrop) cartBackdrop.hidden = true;
        if (focusTarget?.isConnected) focusTarget.focus({preventScroll: true});
      }
    }, 220);
  };
  if (cartOpenButton && cartDrawer) {
    cartOpenButton.addEventListener('click', event => {
      event.preventDefault();
      openCartDrawer();
    });
    cartBackdrop?.addEventListener('click', closeCartDrawer);
    cartDrawer.addEventListener('click', event => {
      if (event.target.closest('[data-cart-close]')) closeCartDrawer();
    });
    document.addEventListener('keydown', event => {
      if (!cartDrawer.classList.contains('is-open')) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        closeCartDrawer();
        return;
      }
      if (event.key !== 'Tab') return;
      const focusable = getCartFocusable();
      if (!focusable.length) {
        event.preventDefault();
        cartDrawer.querySelector('[data-cart-close]')?.focus({preventScroll: true});
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus({preventScroll: true});
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus({preventScroll: true});
      }
    });
    const submitCartUpdate = async (item, quantity, removeItem = false) => {
      if (!cartDrawerForm || cartUpdating) return;
      cartUpdating = true;
      cartDrawer.classList.add('is-updating');
      const action = cartDrawerForm.getAttribute('action') || '/cart';
      try {
        const cartApi = getYouCanCartApi();
        const cartItemId = item?.dataset.cartItemId;
        const productVariantId = item?.dataset.cartVariantId;
        if (cartApi && cartItemId && productVariantId) {
          const updatePayload = {cartItemId, productVariantId, quantity};
          if (removeItem && typeof cartApi.removeItem === 'function') await cartApi.removeItem(updatePayload);
          else if (typeof cartApi.updateItem === 'function') await cartApi.updateItem(updatePayload);
          else throw new Error('cart SDK update unavailable');
        } else {
          const payload = getFormPayload(cartDrawerForm);
          const response = await window.fetch(action, {method: 'POST', body: payload.body, credentials: 'same-origin', redirect: 'follow', headers: Object.assign({Accept: 'text/html,application/xhtml+xml,application/json'}, payload.headers)});
          if (!response.ok) throw new Error('cart update failed');
        }
        try { window.sessionStorage.setItem('muskane-cart-open', '1'); } catch (error) {}
        window.location.reload();
      } catch (error) {
        cartUpdating = false;
        cartDrawer.classList.remove('is-updating');
        HTMLFormElement.prototype.submit.call(cartDrawerForm);
      }
    };
    cartDrawerForm.addEventListener('click', event => {
      const increment = event.target.closest('[data-cart-increment]');
      const decrement = event.target.closest('[data-cart-decrement]');
      const remove = event.target.closest('[data-cart-remove]');
      if (!increment && !decrement && !remove) return;
      event.preventDefault();
      const item = event.target.closest('[data-cart-item]');
      const input = item?.querySelector('[data-cart-quantity]');
      if (!input) return;
      const current = Math.max(0, parseInt(input.value, 10) || 0);
      const nextQuantity = remove ? 0 : (increment ? current + 1 : Math.max(0, current - 1));
      input.value = String(nextQuantity);
      input.setAttribute('value', input.value);
      syncCartQuantityValue(input);
      submitCartUpdate(item, nextQuantity, remove || nextQuantity === 0);
    });
    cartDrawerForm.addEventListener('change', event => {
      const input = event.target.closest('[data-cart-quantity]');
      if (!input) return;
      input.value = String(Math.max(0, parseInt(input.value, 10) || 0));
      input.setAttribute('value', input.value);
      syncCartQuantityValue(input);
      submitCartUpdate(input.closest('[data-cart-item]'), Number.parseInt(input.value, 10) || 0, input.value === '0');
    });
    try {
      if (window.sessionStorage.getItem('muskane-cart-open') === '1') {
        window.sessionStorage.removeItem('muskane-cart-open');
        openCartDrawer();
      }
    } catch (error) {}
  }
  const bar = document.querySelector('[data-buy-bar]');
  const purchase = document.getElementById('product-purchase');
  if (!bar || !purchase) return;
  const related = document.getElementById('related-products');
  let purchaseVisible = false;
  let relatedSeen = false;
  const update = () => {
    const visible = window.matchMedia('(max-width: 767px)').matches && !purchaseVisible && !relatedSeen;
    bar.hidden = !visible;
    document.body.classList.toggle('has-sticky-buy', visible);
  };
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(entries => {
      purchaseVisible = entries.some(entry => entry.isIntersecting);
      update();
    }, {threshold: 0.12}).observe(purchase);
    if (related) {
      new IntersectionObserver(entries => {
        if (entries.some(entry => entry.isIntersecting)) relatedSeen = true;
        update();
      }, {threshold: 0.02}).observe(related);
    }
  } else {
    window.addEventListener('scroll', () => {
      const top = purchase.getBoundingClientRect().top;
      purchaseVisible = top < window.innerHeight && top > 0;
      if (related && related.getBoundingClientRect().top < window.innerHeight) relatedSeen = true;
      update();
    }, {passive:true});
  }
  update();
})();
